# ReadMe 
anne pro key firmware with 6kro base from version 1.4

##Filelist
* Filename: 【TargetId 0】anne pro key fw with 6kro.dfu
* Filename: 【TargetId 1】anne pro led 1.4

## Feature
* 6kro: ON
* FnLock:OFF 
* LayoutLock:OFF
